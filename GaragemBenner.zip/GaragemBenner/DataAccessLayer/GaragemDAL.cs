﻿using DataTraceObject;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public class GaragemDAL
    {
        public void MarcarEntrada(Garagem garagem)
        {
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = DbConfig.connectionString;
                SqlCommand command = new SqlCommand();
                command.CommandText = "INSERT INTO GARAGEM (PLACA,HORARIOCHEGADA,ATIVO)VALUES(@PLACA,@HORARIOCHEGADA,@ATIVO)";
                command.Parameters.AddWithValue("@PLACA", garagem.Placa);
                command.Parameters.AddWithValue("@HORARIOCHEGADA", garagem.HoraChegada);
                command.Parameters.AddWithValue("@ATIVO", garagem.Ativo);
                command.Connection = connection;
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void MarcarSaida(Garagem garagem)
        {
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = DbConfig.connectionString;
                SqlCommand command = new SqlCommand();
                command.CommandText = "INSERT INTO GARAGEM (PLACA,HORARIOCHEGADA,HORARIOSAIDA,DURACAO,TEMPOCOBRADO,PRECO,VALORTOTAL,ATIVO)VALUES (@PLACA,@HORARIOCHEGADA,@HORARIOSAIDA,@DURACAO,@TEMPOCOBRADO,@PRECO,@VALORTOTAL,@ATIVO)";
                command.Parameters.AddWithValue("@PLACA", garagem.Placa);
                command.Parameters.AddWithValue("@HORARIOCHEGADA", garagem.HoraChegada);
                command.Parameters.AddWithValue("@HORARIOSAIDA", garagem.HorarioSaida);
                command.Parameters.AddWithValue("@DURACAO", garagem.Duracao);
                command.Parameters.AddWithValue("@TEMPOCOBRADO", garagem.TempoCombrado);
                command.Parameters.AddWithValue("@PRECO", garagem.Preco);
                command.Parameters.AddWithValue("@VALORTOTAL", garagem.ValorTotal);
                command.Parameters.AddWithValue("@ATIVO", false);
                command.Connection = connection;
                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public List<Garagem> LerTodosCarrosAtivo()
        {
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = DbConfig.connectionString;
                SqlCommand command = new SqlCommand();
                command.CommandText = "SELECT * FROM GARAGEM where ATIVO = 1";
                command.Connection = connection;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                List<Garagem> carros = new List<Garagem>();
                while (reader.Read())
                {
                    Garagem carro = new Garagem();
                    carro.Id = (int)reader["ID"];
                    if (reader["PLACA"] != DBNull.Value)
                    {
                        carro.Placa = (string)reader["PLACA"];
                    }
                    if (reader["HORARIOCHEGADA"] != DBNull.Value)
                    {
                        carro.HoraChegada = (DateTime)reader["HORARIOCHEGADA"];
                    }
                    if (reader["HORARIOSAIDA"] != DBNull.Value)
                    {
                        carro.HorarioSaida = (DateTime)reader["HORARIOSAIDA"];
                    }
                    else if (reader["DURACAO"] != DBNull.Value)
                    {
                        carro.Duracao = (DateTime)reader["DURACAO"];
                    }
                    else if (reader["TEMPOCOBRADO"] != DBNull.Value)
                    {
                        carro.TempoCombrado = Convert.ToInt32(reader["TEMPOCOBRADO"]);
                    }
                    else if (reader["PRECO"] != DBNull.Value)
                    {
                        carro.Preco = (double)reader["PRECO"];
                    }
                    else if (reader["VALORTOTAL"] != DBNull.Value)
                    {
                        carro.ValorTotal = (double)reader["VALORTOTAL"];
                    }

                    carros.Add(carro);
                }
                return carros;
            }
        }

        public List<Garagem> LerTodosCarrosDesativo()
        {
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = DbConfig.connectionString;
                SqlCommand command = new SqlCommand();
                command.CommandText = "SELECT * FROM GARAGEM where ATIVO = 0" +
                    "";
                command.Connection = connection;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                List<Garagem> carros = new List<Garagem>();
                while (reader.Read())
                {
                    Garagem carro = new Garagem();
                    carro.Id = (int)reader["ID"];
                    if (reader["PLACA"] != DBNull.Value)
                    {
                        carro.Placa = (string)reader["PLACA"];
                    }
                    if (reader["HORARIOCHEGADA"] != DBNull.Value)
                    {
                        carro.HoraChegada = (DateTime)reader["HORARIOCHEGADA"];
                    }
                    if (reader["HORARIOSAIDA"] != DBNull.Value)
                    {
                        carro.HorarioSaida = (DateTime)reader["HORARIOSAIDA"];
                    }
                    else if (reader["DURACAO"] != DBNull.Value)
                    {
                        carro.Duracao = (DateTime)reader["DURACAO"];
                    }
                    else if (reader["TEMPOCOBRADO"] != DBNull.Value)
                    {
                        carro.TempoCombrado = Convert.ToInt32(reader["TEMPOCOBRADO"]);
                    }
                    else if (reader["PRECO"] != DBNull.Value)
                    {
                        carro.Preco = (double)reader["PRECO"];
                    }
                    else if (reader["VALORTOTAL"] != DBNull.Value)
                    {
                        carro.ValorTotal = (double)reader["VALORTOTAL"];
                    }

                    carros.Add(carro);
                }
                return carros;
            }
        }

        public List<Garagem> LerTodosCarros(string texto)
        {
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = DbConfig.connectionString;
                SqlCommand command = new SqlCommand();
                command.CommandText = "SELECT * FROM GARAGEM WHERE PLACA LIKE '%"+texto+"%'";
                command.Connection = connection;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                List<Garagem> carros = new List<Garagem>();
                while (reader.Read())
                {
                    Garagem carro = new Garagem();
                    carro.Id = (int)reader["ID"];
                    if (reader["PLACA"] != DBNull.Value)
                    {
                        carro.Placa = (string)reader["PLACA"];
                    }
                    if (reader["HORARIOCHEGADA"] != DBNull.Value)
                    {
                        carro.HoraChegada = (DateTime)reader["HORARIOCHEGADA"];
                    }
                    if (reader["HORARIOSAIDA"] != DBNull.Value)
                    {
                        carro.HorarioSaida = (DateTime)reader["HORARIOSAIDA"];
                    }
                    else if (reader["DURACAO"] != DBNull.Value)
                    {
                        carro.Duracao = (DateTime)reader["DURACAO"];
                    }
                    else if (reader["TEMPOCOBRADO"] != DBNull.Value)
                    {
                        carro.TempoCombrado = Convert.ToInt32(reader["TEMPOCOBRADO"]);
                    }
                    else if (reader["PRECO"] != DBNull.Value)
                    {
                        carro.Preco = (double)reader["PRECO"];
                    }
                    else if (reader["VALORTOTAL"] != DBNull.Value)
                    {
                        carro.ValorTotal = (double)reader["VALORTOTAL"];
                    }

                    carros.Add(carro);
                }
                return carros;
            }
        }
        public void Deletar(int id)
        {
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = DbConfig.connectionString;
                SqlCommand command = new SqlCommand();
                command.CommandText = "UPDATE GARAGEM SET ATIVO=@ATIVO WHERE ID=@ID";
                command.Parameters.AddWithValue("@ATIVO", false);
                command.Parameters.AddWithValue("@ID", id);
                command.Connection = connection;
                connection.Open();
                command.ExecuteNonQuery();
            }
        }
    }
}

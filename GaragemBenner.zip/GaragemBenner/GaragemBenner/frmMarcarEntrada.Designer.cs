﻿namespace GaragemBenner
{
    partial class frmMarcarEntrada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.mktPlaca = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnMarcarEntrada = new System.Windows.Forms.Button();
            this.lblEntradaTime = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.chkAtivo = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(171, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Placa";
            // 
            // mktPlaca
            // 
            this.mktPlaca.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mktPlaca.Location = new System.Drawing.Point(101, 34);
            this.mktPlaca.Name = "mktPlaca";
            this.mktPlaca.Size = new System.Drawing.Size(196, 13);
            this.mktPlaca.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(152, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Horário da entrada";
            // 
            // btnMarcarEntrada
            // 
            this.btnMarcarEntrada.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMarcarEntrada.Location = new System.Drawing.Point(101, 154);
            this.btnMarcarEntrada.Name = "btnMarcarEntrada";
            this.btnMarcarEntrada.Size = new System.Drawing.Size(196, 69);
            this.btnMarcarEntrada.TabIndex = 3;
            this.btnMarcarEntrada.Text = "Marcar Entrada";
            this.btnMarcarEntrada.UseVisualStyleBackColor = true;
            this.btnMarcarEntrada.Click += new System.EventHandler(this.btnMarcarEntrada_Click);
            // 
            // lblEntradaTime
            // 
            this.lblEntradaTime.AutoSize = true;
            this.lblEntradaTime.Location = new System.Drawing.Point(181, 111);
            this.lblEntradaTime.Name = "lblEntradaTime";
            this.lblEntradaTime.Size = new System.Drawing.Size(12, 13);
            this.lblEntradaTime.TabIndex = 4;
            this.lblEntradaTime.Text = "x";
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(142, 230);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 30);
            this.button1.TabIndex = 5;
            this.button1.Text = "Cancelar Entrada";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // chkAtivo
            // 
            this.chkAtivo.AutoSize = true;
            this.chkAtivo.Checked = true;
            this.chkAtivo.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkAtivo.Enabled = false;
            this.chkAtivo.Location = new System.Drawing.Point(155, 131);
            this.chkAtivo.Name = "chkAtivo";
            this.chkAtivo.Size = new System.Drawing.Size(50, 17);
            this.chkAtivo.TabIndex = 6;
            this.chkAtivo.Text = "Ativo";
            this.chkAtivo.UseVisualStyleBackColor = true;
            // 
            // frmMarcarEntrada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 272);
            this.Controls.Add(this.chkAtivo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblEntradaTime);
            this.Controls.Add(this.btnMarcarEntrada);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.mktPlaca);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMarcarEntrada";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.frmMarcarEntrada_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox mktPlaca;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnMarcarEntrada;
        private System.Windows.Forms.Label lblEntradaTime;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox chkAtivo;
    }
}
﻿using BusinessLogicLayer;
using DataTraceObject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaragemBenner
{
    public partial class frmMarcarEntrada : Form
    {
        public frmMarcarEntrada()
        {
            InitializeComponent();
        }

        private void frmMarcarEntrada_Load(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;
            lblEntradaTime.Text = dt.ToString();
        }

        private void btnMarcarEntrada_Click(object sender, EventArgs e)
        {
            Garagem garagem = new Garagem();
            GaragemBLL bll = new GaragemBLL();

            garagem.Placa = mktPlaca.Text;
            garagem.HoraChegada = Convert.ToDateTime(lblEntradaTime.Text);
            garagem.Ativo = chkAtivo.Checked;
            try
            {
                bll.MarcarEntrada(garagem);
                MessageBox.Show("Carro registrado com sucesso!");
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmGaragem inicio = new frmGaragem();
            inicio.ShowDialog();
        }
    }
}

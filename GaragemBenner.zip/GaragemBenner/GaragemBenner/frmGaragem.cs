﻿using BusinessLogicLayer;
using DataTraceObject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaragemBenner
{
    public partial class frmGaragem : Form
    {
        public frmGaragem()
        {
            InitializeComponent();
        }
        GaragemBLL bll = new GaragemBLL();
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMarcarEntrada entrada = new frmMarcarEntrada();
            entrada.ShowDialog();
        }

        private void btnSaida_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMarcarSaida saida = new frmMarcarSaida();
            saida.ShowDialog();
        }

        private void frmGaragem_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = bll.LerTodosCarrosDesativo();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Garagem garagem = (Garagem)dataGridView1.SelectedRows[0].DataBoundItem;
        }

        private void buscarVeículoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmBuscarCarro seach = new frmBuscarCarro();
            seach.ShowDialog();
        }

        
    }
}

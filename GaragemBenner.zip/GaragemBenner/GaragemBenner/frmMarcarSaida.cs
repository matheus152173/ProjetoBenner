﻿using BusinessLogicLayer;
using DataTraceObject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaragemBenner
{
    public partial class frmMarcarSaida : Form
    {
        public frmMarcarSaida()
        {
            InitializeComponent();
        }
        GaragemBLL bll = new GaragemBLL();
        Garagem garagem = new Garagem();

        private void dgvSaida_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Garagem garage = (Garagem)dgvSaida.SelectedRows[0].DataBoundItem;
            int valor = 0;
            txtPlaca.Text = garage.Placa;
            dtpChegada.Value = garage.HoraChegada;
            garage.HorarioSaida = DateTime.Now;

            if(dtpSaida.Value == null)
            {
                dtpSaida.Value = garage.HorarioSaida;
            }

            TimeSpan dt = garage.HorarioSaida.Subtract(garage.HoraChegada);
            txtDuracao.Text = string.Format("{0}:{1}:{2}", dt.Hours,dt.Minutes,dt.Seconds);

             if(dt.Minutes > 10 && dt.Minutes < 30) 
            {
                txtTempoCobrado.Text = "1";
                double total = valor + 1;
                txtPreco.Text = total.ToString();
                txtValorTotal.Text = string.Format("{0:c}", total);
            }
           
            else if(dt.Hours == 1)
            {
                txtTempoCobrado.Text = "1";
                double total = valor = 2;
                txtPreco.Text = total.ToString();
                txtPreco.Text = string.Format("{0:c}", total);
            }

            else if (dt.Hours == 1 && dt.Minutes <= 10)
            {
                txtTempoCobrado.Text = "1";
                double total = valor = 2;
                txtPreco.Text = total.ToString();
                txtPreco.Text = string.Format("{0:c}", total);
            }

            else if(dt.Hours == 1 && dt.Minutes <= 15)
            {
                txtTempoCobrado.Text = "2";
                double total = valor+ 3;
                txtPreco.Text = total.ToString();
                txtPreco.Text = string.Format("{0:c}", total);
            }
            else if(dt.Hours == 2 && dt.Minutes <= 5)
            {
                txtTempoCobrado.Text = "3";
                double total = valor + 3;
                txtPreco.Text = total.ToString();
                txtPreco.Text = string.Format("{0:c}",total);
            }
            else if(dt.Hours > 3)
            {
                txtTempoCobrado.Text = "4";
                double total = valor + 4;
                txtPreco.Text = total.ToString();
                txtValorTotal.Text = string.Format("{0:c}",total);
            }
            txtID.Text = garage.Id.ToString();
            checkBox2.Checked = garage.Ativo;
        }

        private void btnSaida_Click(object sender, EventArgs e)
        {
            GaragemBLL bll = new GaragemBLL();
            garagem.Placa = txtPlaca.Text;
            garagem.HoraChegada = dtpChegada.Value;
            garagem.HorarioSaida = dtpSaida.Value;
            garagem.Duracao = Convert.ToDateTime(txtDuracao.Text);
            garagem.TempoCombrado = txtTempoCobrado.TextLength;
            garagem.Preco = txtTempoCobrado.TextLength;
            garagem.ValorTotal = txtValorTotal.TextLength;
            garagem.Ativo = checkBox2.Checked;
            try
            {
                bll.MarcarSaida(garagem);
                MessageBox.Show("Saída marcada com sucesso!");
                dgvSaida.DataSource = bll.LerTodosCarrosAtivo();
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void frmMarcarSaida_Load(object sender, EventArgs e)
        {
            dgvSaida.DataSource = bll.LerTodosCarrosAtivo();
            garagem.Id = txtID.TextLength;
            garagem.Placa = txtPlaca.Text;
            garagem.HoraChegada = dtpChegada.Value;
            if (garagem.HorarioSaida == null)
            {
                garagem.HorarioSaida = dtpSaida.Value; 
            }
            garagem.HorarioSaida = dtpSaida.Value;
            garagem.TempoCombrado = txtTempoCobrado.TextLength;
            garagem.Preco = txtPreco.TextLength;
            garagem.ValorTotal = txtValorTotal.TextLength;
            garagem.Ativo = checkBox2.Checked;
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmGaragem inicio = new frmGaragem();
            inicio.ShowDialog();
        }
    }
}

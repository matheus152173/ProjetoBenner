﻿using BusinessLogicLayer;
using DataTraceObject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GaragemBenner
{
    public partial class frmBuscarCarro : Form
    {
        public frmBuscarCarro()
        {
            InitializeComponent();
        }
        GaragemBLL bll = new GaragemBLL();
        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            Garagem garagem = new Garagem();
            garagem.Placa = txtPlaca.Text;
            try
            {
                var nomes = bll.LerTodosCarrosPorLetra(txtPlaca.Text);
                foreach (var item in nomes)
                {
                    nomes.Select(c => c.Placa);
                }
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvBuscar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Garagem garagem = (Garagem)dgvBuscar.SelectedRows[0].DataBoundItem;
        }

        private void frmBuscarCarro_Load(object sender, EventArgs e)
        {
            dgvBuscar.DataSource = bll.LerTodosCarrosPorLetra(txtPlaca.Text);
        }
    }
}

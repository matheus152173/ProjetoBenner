﻿using DataTraceObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public interface ICrud
    {
        void MarcarEntrada(Garagem garagem);
        void MarcarSaida(Garagem garagem);
        void Deletar(int id);
        List<Garagem> LerTodosCarrosAtivo();
        List<Garagem> LerTodosCarrosDesativo();
        List<Garagem> LerTodosCarrosPorLetra(string texto);
    }
}

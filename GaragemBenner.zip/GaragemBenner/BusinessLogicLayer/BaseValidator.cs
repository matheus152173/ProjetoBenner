﻿using DataTraceObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogicLayer
{
    public class BaseValidator<T>
    {
        private List<ErrorField> errors = new List<ErrorField>();

        protected void AddError(ErrorField error)
        {
            this.errors.Add(error);
        }
        protected void AddError(string fieldName, string message)
        {
            this.errors.Add(new ErrorField()
            {
                FieldName = fieldName,
                Message = message
            });
        }
        protected virtual void Validate(T item)
        {

        }
        private void CheckErrors()
        {
            if(this.errors.Count != 0)
            {
                throw new CustomException(this.errors);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataAccessLayer;
using DataTraceObject;

namespace BusinessLogicLayer
{
    public class GaragemBLL : BaseValidator<Garagem>,ICrud
    {
        GaragemDAL dal = new GaragemDAL();
        protected override void Validate(Garagem item)
        {
            if (string.IsNullOrWhiteSpace(item.Placa))
            {
                AddError("Placa", "A placa deve ser informada");
            }
            if (item.Preco == 0)
            {
                AddError("Preco", "O preço deve ser informado");
            }
            if(item.ValorTotal == 0)
            {
                AddError("ValorTotal", "Você não tem valor estipulado para fechar.");
            }
            if(item.HorarioSaida == null)
            {
                AddError("HorarioSaida", "Informe o horário de saída");
            }
            base.Validate(item);
        }
        public void MarcarEntrada(Garagem garagem)
        {
            try
            {
                dal.MarcarEntrada(garagem);
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void MarcarSaida(Garagem garagem)
        {
            try
            {
                Validate(garagem);
                dal.MarcarSaida(garagem);
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public List<Garagem> LerTodosCarrosAtivo()
        {
            return dal.LerTodosCarrosAtivo();
        }

        public List<Garagem> LerTodosCarrosDesativo()
        {
            return dal.LerTodosCarrosDesativo();
        }

        public List<Garagem> LerTodosCarrosPorLetra(string texto)
        {
            return dal.LerTodosCarros(texto);
        }

        public void Deletar(int id)
        {
            try
            {
                dal.Deletar(id);
            }
            catch (CustomException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
    }
}

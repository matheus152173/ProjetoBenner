﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTraceObject
{
    public class Garagem
    {
        public int Id { get; set; }
        public string Placa { get; set; }
        public DateTime HoraChegada { get; set; }
        public DateTime HorarioSaida { get; set; }
        public DateTime Duracao { get; set; }
        public int TempoCombrado { get; set; }
        public double Preco { get; set; }
        public double ValorTotal { get; set; }
        public bool Ativo { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DataTraceObject
{
    [Serializable]
    public class CustomException : Exception
    {
        public List<ErrorField> Errors { get; private set; }

        public string GetMessage()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var item in Errors)
            {
                sb.AppendLine(item.Message);
            }
            return sb.ToString();
        }
        public CustomException()
        {
        }
        public CustomException(List<ErrorField> errors)
        {
            this.Errors = errors;
        }

        public CustomException(string message) : base(message)
        {
        }

        public CustomException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected CustomException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}

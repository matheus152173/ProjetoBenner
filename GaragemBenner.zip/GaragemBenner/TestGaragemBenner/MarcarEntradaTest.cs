using BusinessLogicLayer;
using DataAccessLayer;
using DataTraceObject;
using NUnit.Framework;
using FluentAssertions;
using System;


namespace Tests
{
    public class Tests
    {
        private readonly ICrud _marcarEntrada;

        public Tests()
        {
            _marcarEntrada = new GaragemBLL();
        }

        [Test]
        public void MarcarEntradaCorreta()
        {
            var garagem = new Garagem();
            garagem.Id = 1;
            garagem.Placa = "MKT-4343";
            garagem.HoraChegada = DateTime.Now;
            garagem.HorarioSaida = DateTime.Now;
            garagem.TempoCombrado = 1;
            garagem.Preco = 2;
            garagem.ValorTotal = 4;
            garagem.Should().NotBeNull();
        }
        [Test]
        public void MarcarEntradaErrada()
        {
            var garagem = new Garagem();
            garagem.Id = 1;
            garagem.Placa = "";
            garagem.HoraChegada = DateTime.Now;
            garagem.HorarioSaida = DateTime.Now;
            garagem.TempoCombrado = 2;
            garagem.Preco = 3;
            garagem.ValorTotal = 3;
            garagem.Should().NotBeNull();
            
        }
        [Test]
        public void MarcarSaidaCorreta()
        {
            var dal = new GaragemDAL();
            var garagem = new Garagem();
            garagem.Id = 1;
            garagem.Placa = "GDS-2131";
            garagem.HoraChegada = DateTime.Now;
            garagem.HorarioSaida = DateTime.Now;
            garagem.TempoCombrado = 2;
            garagem.Preco = 3;
            garagem.ValorTotal = 3;
            garagem.Invoking(dal.MarcarSaida);
        }
    }
}
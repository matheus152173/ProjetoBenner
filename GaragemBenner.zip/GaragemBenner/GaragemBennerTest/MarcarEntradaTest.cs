using System;
using Xunit;

namespace GaragemBennerTest
{
    public class MarcarEntradaTest
    {
        [Fact]
        public void MarcarEntradaCorreta()
        {
            
        }
    }
}
